# Canzoni Coro V20

Versione Android offline. Base V13, con elenco alfabetico, modifica nome, zoom con due dita, Galleria, importazione/condivisione da WhatsApp, INFO con EXIF, eliminazione e icona personalizzata.
